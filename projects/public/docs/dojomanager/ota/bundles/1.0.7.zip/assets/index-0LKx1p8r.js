const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CqMaavIk.js","./index-Dgjwe886.js","./index-3XHGLVCW.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-Dgjwe886.js";const o=r("App",{web:()=>p(()=>import("./web-CqMaavIk.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
