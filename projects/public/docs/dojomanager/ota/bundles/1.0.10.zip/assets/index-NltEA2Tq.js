const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CVzY1mAN.js","./index-BfpEc1ra.js","./index-3XHGLVCW.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-BfpEc1ra.js";const o=r("App",{web:()=>p(()=>import("./web-CVzY1mAN.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
