const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-B--Kf5kq.js","./index-CqUInxnx.js","./index-BNS3JQkG.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-CqUInxnx.js";const o=r("App",{web:()=>p(()=>import("./web-B--Kf5kq.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
