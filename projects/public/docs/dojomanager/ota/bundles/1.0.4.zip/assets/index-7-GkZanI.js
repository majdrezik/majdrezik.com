const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-Cet2ufNA.js","./index-eZ15FHSF.js","./index-BNS3JQkG.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-eZ15FHSF.js";const o=r("App",{web:()=>p(()=>import("./web-Cet2ufNA.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
