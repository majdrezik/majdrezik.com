import{W as n}from"./index-C5ErDn06.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
