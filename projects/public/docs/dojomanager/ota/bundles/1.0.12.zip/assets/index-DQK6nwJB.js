const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CkJKfRu9.js","./index-BwSIndiO.js","./index-C0hmsrLJ.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-BwSIndiO.js";const o=r("App",{web:()=>p(()=>import("./web-CkJKfRu9.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
