import{W as n}from"./index-Yl3w5AyK.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
