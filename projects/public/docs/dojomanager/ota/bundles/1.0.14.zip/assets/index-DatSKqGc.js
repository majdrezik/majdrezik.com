const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CFwGJWbg.js","./index-CvNVVwVl.js","./index-C0hmsrLJ.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-CvNVVwVl.js";const o=r("App",{web:()=>p(()=>import("./web-CFwGJWbg.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
