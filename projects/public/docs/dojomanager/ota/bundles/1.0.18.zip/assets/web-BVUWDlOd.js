import{W as n}from"./index-CZDx3po2.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
