import{W as n}from"./index-BfpEc1ra.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
