const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DGE0WQYy.js","./index-DzrVUkm7.js","./index-CqB38Q-1.css"])))=>i.map(i=>d[i]);
import{r,_ as p}from"./index-DzrVUkm7.js";const o=r("App",{web:()=>p(()=>import("./web-DGE0WQYy.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.AppWeb)});export{o as App};
