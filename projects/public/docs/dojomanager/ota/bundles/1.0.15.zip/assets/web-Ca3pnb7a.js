import{W as n}from"./index-7Cu3hU2o.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
